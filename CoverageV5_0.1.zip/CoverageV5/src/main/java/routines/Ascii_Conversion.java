package routines;


public class Ascii_Conversion {

    /**
     * helloExample: not return value, only print "hello" + message.
     * 
     * 
     * {talendTypes} String
     * 
     * {Category} User Defined
     * 
     * {param} string("world") input: The string need to be printed.
     * 
     * {example} helloExemple("world") # hello world !.
     */
    public static void helloExample(String message) {
        if (message == null) {
            message = "World"; //$NON-NLS-1$
        }
        System.out.println("Hello " + message + " !"); //$NON-NLS-1$ //$NON-NLS-2$
    }
    
	/**
     * asciiToInt: not return value, only print "hello" + message.
     * 
     * 
     * {talendTypes} String
     * 
     * {Category} User Defined
     * 
     * {param} string("world") input: The string need to be printed.
     * 
     * {example} asciiToInt("world") # hello world !.
     */
    public static int asciiToInt(String str) {
        
    	 String name = str; 
		 Integer ascii = 0;
		 String convertId ="";
        
		int nameLenght = name.length();
		for(int i = 0; i < nameLenght ; i++){         
			char character = name.charAt(i);
			ascii = (int) character;
			convertId += ascii.toString();
			
        }
        ascii = Integer.parseInt(convertId);
		
		return ascii;
 
    }
    
    
}